import { useState } from 'react'
import axios from 'axios'
import './App.css'

function App() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    age: '',
    position: '',
    experience: '',
    emergencyContact: '',
    emergencyPhone: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitMessage, setSubmitMessage] = useState('')

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsSubmitting(true)
    setSubmitMessage('')

    try {
      // Replace with your Google Apps Script web app URL
      const scriptURL = import.meta.env.VITE_GOOGLE_SCRIPT_URL

      if (!scriptURL) {
        throw new Error('Google Script URL not configured. Please set VITE_GOOGLE_SCRIPT_URL in your .env file.')
      }

      const response = await axios.post(scriptURL, formData, {
        headers: {
          'Content-Type': 'application/json'
        }
      })

      if (response.status === 200) {
        setSubmitMessage('Registration submitted successfully!')
        setFormData({
          firstName: '',
          lastName: '',
          email: '',
          phone: '',
          age: '',
          position: '',
          experience: '',
          emergencyContact: '',
          emergencyPhone: ''
        })
      }
    } catch (error) {
      console.error('Error submitting form:', error)
      setSubmitMessage('Error submitting registration. Please try again.')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="app">
      <div className="container">
        <h1>Football Camp Registration</h1>
        <p>Please fill out the form below to register for our football camp.</p>

        <form onSubmit={handleSubmit} className="registration-form">
          <div className="form-group">
            <label htmlFor="firstName">First Name *</label>
            <input
              type="text"
              id="firstName"
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="lastName">Last Name *</label>
            <input
              type="text"
              id="lastName"
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="email">Email *</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="phone">Phone Number *</label>
            <input
              type="tel"
              id="phone"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="age">Age *</label>
            <input
              type="number"
              id="age"
              name="age"
              value={formData.age}
              onChange={handleChange}
              min="8"
              max="18"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="position">Preferred Position</label>
            <select
              id="position"
              name="position"
              value={formData.position}
              onChange={handleChange}
            >
              <option value="">Select Position</option>
              <option value="Quarterback">Quarterback</option>
              <option value="Running Back">Running Back</option>
              <option value="Wide Receiver">Wide Receiver</option>
              <option value="Tight End">Tight End</option>
              <option value="Offensive Line">Offensive Line</option>
              <option value="Linebacker">Linebacker</option>
              <option value="Defensive Back">Defensive Back</option>
              <option value="Defensive Line">Defensive Line</option>
              <option value="Kicker">Kicker</option>
              <option value="Punter">Punter</option>
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="experience">Football Experience</label>
            <textarea
              id="experience"
              name="experience"
              value={formData.experience}
              onChange={handleChange}
              placeholder="Tell us about your football experience..."
              rows="3"
            />
          </div>

          <div className="form-group">
            <label htmlFor="emergencyContact">Emergency Contact Name *</label>
            <input
              type="text"
              id="emergencyContact"
              name="emergencyContact"
              value={formData.emergencyContact}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="emergencyPhone">Emergency Contact Phone *</label>
            <input
              type="tel"
              id="emergencyPhone"
              name="emergencyPhone"
              value={formData.emergencyPhone}
              onChange={handleChange}
              required
            />
          </div>

          <button
            type="submit"
            className="submit-btn"
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Submitting...' : 'Register'}
          </button>

          {submitMessage && (
            <div className={`message ${submitMessage.includes('Error') ? 'error' : 'success'}`}>
              {submitMessage}
            </div>
          )}
        </form>
      </div>
    </div>
  )
}

export default App
